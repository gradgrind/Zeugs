import os, sys
import datetime

_appdir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

from flask import Flask, render_template, request, jsonify
from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.fields.html5 import DateField
from wtforms.validators import InputRequired, Length
#print ("PATH:", sys.path)
#sys.path.insert(1, os.path.dirname(os.path.dirname(_appdir)))
#print ("PATH:", sys.path, os.getcwd())

ZEUGS_BASE = os.environ['ZEUGS_BASE']
sys.path.insert(1,  ZEUGS_BASE)
print ("PATH:", sys.path, os.getcwd())
from wz_core.configuration import init
init(None)

def create_app(test_config=None):
    # create and configure the app
#    app = Flask(__name__, instance_relative_config=True)
    app = Flask(__name__, instance_path=os.path.join (
            os.path.dirname(ZEUGS_BASE), 'instance'),
            instance_relative_config=True)
#    app.config.from_mapping(
#        SECRET_KEY=os.urandom(24),
#        DATABASE=os.path.join(app.instance_path, 'flaskr.sqlite'),
#    )

    app.config.from_object('config') # Load module config.py (this directory).
    if test_config is None:
        # load the config from the instance directory, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
        # load the test config if passed in
        app.config.from_mapping(test_config)

    # ensure the instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    @app.route('/textcover',methods=['GET','POST'])
    def textCover():
        class Form(FlaskForm):
            dateofissue = DateField('Ausgabedatum', default=datetime.date.today,
                                    validators=[InputRequired()])
            itemB = StringField('Anderes Feld', validators=[Length(4, 10,
                    "Das Feld muss zwischen 4 und 10 Zeichen enthalten.")])

        form = Form()
        if form.validate_on_submit():
            return 'Das AusgabeDatum ist {}.'.format(form.dateofissue.data)
        return render_template('textcover_base.html', form=form, schoolyear='2020')

    @app.route('/textcover/data1', methods=('POST',))
    def data1():
        klass = request.json['klass']
        app.logger.info('REQUEST klass: %s' % klass)
        jsonpeople = {
            "fields": ["itemA", "itemB", "itemC",],
            "pupilList": [
                ["001", "Bernd Förster"],
                ["002", "Juli Läßner"],
                ["003", "Franz Neumann"],
                ["004", "Emily Friederike von Riesighausen"],
            ],
            "pupilData": {
                "001": {"itemA": "val 1A", "itemB": "val 1B", "itemC": "val 1C"},
                "002": {"itemA": "val 2A", "itemB": "val 2B", "itemC": "val 2C"},
                "003": {"itemA": "val 3A", "itemB": "val 3B", "itemC": "val 3C"},
                "004": {"itemB": "val 4B"},
            },
        }
        from time import sleep
        sleep (3)
        return jsonify(jsonpeople)
    
    from .text_cover import text_cover
    app.register_blueprint(text_cover.bp, url_prefix='/text_cover')
    
#    from . import db
#    db.init_app(app)

#    from . import auth
#    app.register_blueprint(auth.bp)

#    from . import blog
#    app.register_blueprint(blog.bp)
#    app.add_url_rule('/', endpoint='index')

    return app
