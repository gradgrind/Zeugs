import os

#SECRET_KEY = (os.environ.get('SECRET_KEY')
#                  or 'you-will-never-guess')

#SECRET_KEY = os.urandom(24)

SECRET_KEY = b'\xa5P(\xa7\xc9\x9c\xce\xb3\x99\xa3]\x11x\x0e\xe6\\\xe7\x00\xaa\x0ew.\xf8\x07'
